
  # Rental Marketplace Website

  This is a code bundle for Rental Marketplace Website. The original project is available at https://www.figma.com/design/AvQQHQIWBcR0dVBlTAGh22/Rental-Marketplace-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server <3
  